using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using Steamworks;

/// <summary>
/// 전 세계 리더보드 패널.
/// 1~10위 (이름 + Steam 아바타 + 거리) + 본인 순위/거리.
/// </summary>
public class LeaderboardUI : MonoBehaviour
{
    [Header("Top 10 List")]
    [Tooltip("ScrollRect의 Content 또는 그냥 Vertical Layout Group 컨테이너")]
    public Transform entryContainer;
    [Tooltip("항목 prefab: 자식에 RawImage(아바타) + TMP 3개(rank/name/distance)")]
    public GameObject entryPrefab;

    [Header("My Row (separate, below top 10)")]
    [Tooltip("본인 순위 영역의 아바타")]
    public RawImage myAvatar;
    public TextMeshProUGUI myRankText;
    public TextMeshProUGUI myNameText;
    public TextMeshProUGUI myDistanceText;

    [Header("UI")]
    public TextMeshProUGUI titleText;
    public TextMeshProUGUI loadingText;
    [Tooltip("X 닫기 버튼. 누르면 패널 비활성 + SettingsPanel 복귀.")]
    public Button closeButton;

    [Header("Optional")]
    [Tooltip("닫을 때 다시 보일 부모 SettingsPanel (없어도 됨)")]
    public SettingsPanelUI parentSettingsPanel;

    private List<GameObject> spawnedEntries = new List<GameObject>();
    private ulong mySteamId;

    // 아바타 콜백 (Steam 비동기)
    protected Callback<AvatarImageLoaded_t> avatarLoadedCallback;
    private Dictionary<ulong, RawImage> pendingAvatars = new Dictionary<ulong, RawImage>();

    void Awake()
    {
        if (SteamManager.Initialized)
            avatarLoadedCallback = Callback<AvatarImageLoaded_t>.Create(OnAvatarLoaded);
    }

    void OnEnable()
    {
        // 정박/위젯 모드와 무관하게 정박 크기로 확장
        var wsm = WindowStateManager.Instance;
        if (wsm != null) wsm.ExpandForCollection();

        if (SteamManager.Initialized)
            mySteamId = SteamUser.GetSteamID().m_SteamID;

        if (LeaderboardManager.Instance != null)
        {
            LeaderboardManager.Instance.OnEntriesFetched += OnEntriesFetched;
            LeaderboardManager.Instance.OnMyRankFetched += OnMyRankFetched;
        }

        if (closeButton != null)
            closeButton.onClick.AddListener(Close);

        if (titleText != null) titleText.text = Loc.Get("lb_title");

        FetchAndShow();
    }

    void OnDisable()
    {
        if (LeaderboardManager.Instance != null)
        {
            LeaderboardManager.Instance.OnEntriesFetched -= OnEntriesFetched;
            LeaderboardManager.Instance.OnMyRankFetched -= OnMyRankFetched;
        }

        if (closeButton != null)
            closeButton.onClick.RemoveListener(Close);
    }

    void Close()
    {
        gameObject.SetActive(false);

        // 정박 크기에서 원래 크기로 복귀
        var wsm = WindowStateManager.Instance;
        if (wsm != null) wsm.CollapseFromCollection();

        if (parentSettingsPanel != null)
            parentSettingsPanel.Reopen();
    }

    void FetchAndShow()
    {
        ClearEntries();
        SetLoading(true);

        // 본인 영역 초기화
        if (myRankText != null) myRankText.text = "...";
        if (myDistanceText != null) myDistanceText.text = "";
        if (myNameText != null)
            myNameText.text = SteamManager.Initialized ? SteamFriends.GetPersonaName() : "";
        if (myAvatar != null) LoadAvatar((CSteamID)mySteamId, myAvatar);

        var mgr = LeaderboardManager.Instance;
        if (mgr == null)
        {
            SetLoading(true, Loc.Get("lb_empty"));
            return;
        }

        // 본인 점수 갱신 → 그 후 Top 10 + 본인 순위 조회
        mgr.UploadCurrentScore();
        mgr.FetchGlobalTop(10);
        mgr.FetchMyRank();
    }

    void OnEntriesFetched(List<LeaderboardEntry> entries)
    {
        ClearEntries();
        SetLoading(false);

        if (entries.Count == 0)
        {
            SetLoading(true, Loc.Get("lb_empty"));
            return;
        }

        foreach (var entry in entries)
        {
            var go = Instantiate(entryPrefab, entryContainer);
            spawnedEntries.Add(go);

            // TMP 텍스트들 (자식 순서: rank, name, distance)
            var texts = go.GetComponentsInChildren<TextMeshProUGUI>(true);
            if (texts.Length >= 1) texts[0].text = $"#{entry.rank}";
            if (texts.Length >= 2) texts[1].text = entry.steamName;
            if (texts.Length >= 3) texts[2].text = StarDatabase.FormatKM(entry.distanceKM);

            // 아바타 (자식의 첫 번째 RawImage)
            var avatar = go.GetComponentInChildren<RawImage>(true);
            if (avatar != null)
                LoadAvatar((CSteamID)entry.steamId, avatar);
        }
    }

    void OnMyRankFetched(LeaderboardEntry me)
    {
        if (me == null)
        {
            if (myRankText != null) myRankText.text = "-";
            if (myDistanceText != null) myDistanceText.text = "0 km";
            return;
        }

        if (myRankText != null) myRankText.text = $"#{me.rank}";
        if (myNameText != null) myNameText.text = me.steamName;
        if (myDistanceText != null) myDistanceText.text = StarDatabase.FormatKM(me.distanceKM);
    }

    // ============ Steam Avatar ============

    /// <summary>
    /// Steam 사용자 아바타 로드. 비동기. AvatarImageLoaded_t 콜백 통해 적용됨.
    /// </summary>
    void LoadAvatar(CSteamID steamId, RawImage targetImage)
    {
        if (!SteamManager.Initialized) return;

        int imageHandle = SteamFriends.GetMediumFriendAvatar(steamId);
        if (imageHandle == -1)
        {
            // 아직 로드 안 됨 — Steam이 백그라운드에서 다운로드 후 콜백 발행
            pendingAvatars[steamId.m_SteamID] = targetImage;
            return;
        }
        if (imageHandle == 0) return; // 아바타 없음

        ApplyAvatarImage(imageHandle, targetImage);
    }

    void OnAvatarLoaded(AvatarImageLoaded_t param)
    {
        ulong sid = param.m_steamID.m_SteamID;
        if (pendingAvatars.TryGetValue(sid, out var img) && img != null)
        {
            ApplyAvatarImage(param.m_iImage, img);
            pendingAvatars.Remove(sid);
        }
    }

    void ApplyAvatarImage(int imageHandle, RawImage target)
    {
        if (target == null) return;

        uint w, h;
        if (!SteamUtils.GetImageSize(imageHandle, out w, out h)) return;
        if (w == 0 || h == 0) return;

        int byteCount = (int)(w * h * 4);
        byte[] buffer = new byte[byteCount];
        if (!SteamUtils.GetImageRGBA(imageHandle, buffer, byteCount)) return;

        var tex = new Texture2D((int)w, (int)h, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;

        // Steam은 위에서 아래로 정렬 → Unity는 아래에서 위로 → flip
        var flipped = new byte[byteCount];
        int rowSize = (int)w * 4;
        for (int y = 0; y < h; y++)
        {
            System.Array.Copy(buffer, y * rowSize,
                flipped, (h - 1 - y) * rowSize, rowSize);
        }
        tex.LoadRawTextureData(flipped);
        tex.Apply();
        target.texture = tex;
    }

    void ClearEntries()
    {
        foreach (var go in spawnedEntries) if (go != null) Destroy(go);
        spawnedEntries.Clear();
        pendingAvatars.Clear();
    }

    void SetLoading(bool show, string text = null)
    {
        if (loadingText == null) return;
        loadingText.gameObject.SetActive(show);
        if (show) loadingText.text = text ?? Loc.Get("loading");
    }
}
