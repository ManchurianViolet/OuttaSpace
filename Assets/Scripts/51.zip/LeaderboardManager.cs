using UnityEngine;
using Steamworks;
using System;
using System.Collections.Generic;

/// <summary>
/// Steam Leaderboards 래퍼.
/// 
/// 작동:
/// - 정박 시점에 totalDistance를 Steam에 업로드
/// - LeaderboardUI에서 조회해서 표시
/// 
/// 주의:
/// - Steam Leaderboard 점수는 int32 (최대 약 21억)
/// - 우리 거리는 km 단위로 24,700조까지 가니까 오버플로
/// - "백만 km 단위"로 압축해서 저장 (24,700조 → 24.7억, int32 가능)
/// - 24,700조 / 1,000,000 = 24,700,000,000 → 32비트로는 21억까지만 → 여전히 오버
/// - 더 큰 단위로 압축: "10억 km(=Gm) 단위" → 24,700,000 (안전)
/// </summary>
public class LeaderboardManager : MonoBehaviour
{
    public static LeaderboardManager Instance { get; private set; }

    private const string LEADERBOARD_NAME = "total_distance";

    /// <summary>
    /// 거리를 int32 score로 압축할 때 나누는 값.
    /// 16.5경 km (최대) / 10000 = 1.65 × 10^13 — int32(2.1 × 10^9) 초과
    /// 16.5경 km / 10^7 = 1.65 × 10^9 — int32 안전권
    /// → 1000만 km 단위 (= 0.01 Gm)
    /// 표시 시 다시 곱해서 km로 환산.
    /// 
    /// 작은 거리(달 38만 km)도 잡히려면 더 작은 단위 필요하지만,
    /// int32 한계 때문에 최소 1000만 km 단위가 한계.
    /// </summary>
    public const double SCORE_DIVISOR = 10_000_000.0; // 1000만 km 단위 (0.01 Gm)

    private SteamLeaderboard_t leaderboard;
    private bool leaderboardReady;
    private float uploadTimer;
    private double lastUploadedDistance;

    // 콜백 결과
    private CallResult<LeaderboardFindResult_t> findResult;
    private CallResult<LeaderboardScoreUploaded_t> uploadResult;
    private CallResult<LeaderboardScoresDownloaded_t> downloadResult;

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        if (!SteamManager.Initialized)
        {
            Debug.LogWarning("[Leaderboard] Steam not initialized");
            return;
        }

        findResult = CallResult<LeaderboardFindResult_t>.Create(OnLeaderboardFound);
        uploadResult = CallResult<LeaderboardScoreUploaded_t>.Create(OnScoreUploaded);
        downloadResult = CallResult<LeaderboardScoresDownloaded_t>.Create(OnScoresDownloaded);

        // 시작 시 leaderboard 찾기 (없으면 자동 생성 안 됨 — Steamworks Partner에서 미리 등록 필요)
        var handle = SteamUserStats.FindLeaderboard(LEADERBOARD_NAME);
        findResult.Set(handle);
    }

    void OnLeaderboardFound(LeaderboardFindResult_t result, bool ioFailure)
    {
        if (ioFailure || result.m_bLeaderboardFound == 0)
        {
            Debug.LogWarning($"[Leaderboard] Find failed. ioFailure={ioFailure}");
            return;
        }
        leaderboard = result.m_hSteamLeaderboard;
        leaderboardReady = true;
        Debug.Log($"[Leaderboard] Ready: {LEADERBOARD_NAME}");

        // 처음 발견 시 한 번 업로드 (현재 거리)
        UploadCurrentScore();
    }

    void Update()
    {
        if (!leaderboardReady || GameManager.Instance == null) return;

        // 1분마다 자동 업로드 (거리가 충분히 늘었으면)
        uploadTimer += Time.unscaledDeltaTime;
        if (uploadTimer >= 60f)
        {
            uploadTimer = 0f;
            double cur = GameManager.Instance.totalDistance;
            // 최소 1점(=1000만 km) 이상 늘었을 때만 업로드 (API 절약)
            if (cur - lastUploadedDistance >= SCORE_DIVISOR)
                UploadCurrentScore();
        }
    }

    /// <summary>
    /// 현재 totalDistance를 Steam에 업로드. 더 큰 값일 때만 갱신됨 (Steam이 처리).
    /// </summary>
    public void UploadCurrentScore()
    {
        if (!leaderboardReady || GameManager.Instance == null) return;

        double km = GameManager.Instance.totalDistance;
        if (km < 0) km = 0;

        // 압축: km / 10억 = int32 안전
        long compressed = (long)(km / SCORE_DIVISOR);
        if (compressed > int.MaxValue) compressed = int.MaxValue;
        int score = (int)compressed;

        lastUploadedDistance = km;

        var handle = SteamUserStats.UploadLeaderboardScore(
            leaderboard,
            ELeaderboardUploadScoreMethod.k_ELeaderboardUploadScoreMethodKeepBest, // 최고점만 유지
            score,
            null, 0);
        uploadResult.Set(handle);

        Debug.Log($"[Leaderboard] Uploading: {km:N0} km → score {score:N0}");
    }

    void OnScoreUploaded(LeaderboardScoreUploaded_t result, bool ioFailure)
    {
        if (ioFailure || result.m_bSuccess == 0)
        {
            Debug.LogWarning($"[Leaderboard] Upload failed. ioFailure={ioFailure}");
            return;
        }
        Debug.Log($"[Leaderboard] Uploaded. Global rank: {result.m_nGlobalRankNew}");
    }

    // ============ 조회 ============

    public event Action<List<LeaderboardEntry>> OnEntriesFetched;
    public event Action<LeaderboardEntry> OnMyRankFetched;

    // 어떤 요청에 대한 응답인지 구분 (Steam API는 콜백 자체엔 정보 없음)
    private enum FetchKind { Global, MyRank }
    private FetchKind lastFetchKind;

    /// <summary>
    /// 전 세계 상위 N명 조회.
    /// </summary>
    public void FetchGlobalTop(int count = 50)
    {
        if (!leaderboardReady) return;
        lastFetchKind = FetchKind.Global;
        var handle = SteamUserStats.DownloadLeaderboardEntries(
            leaderboard,
            ELeaderboardDataRequest.k_ELeaderboardDataRequestGlobal,
            1, count);
        downloadResult.Set(handle);
    }

    /// <summary>
    /// 본인 한 명만 조회 (전 세계 순위 안에서 본인 위치).
    /// </summary>
    public void FetchMyRank()
    {
        if (!leaderboardReady) return;
        lastFetchKind = FetchKind.MyRank;
        var handle = SteamUserStats.DownloadLeaderboardEntries(
            leaderboard,
            ELeaderboardDataRequest.k_ELeaderboardDataRequestGlobalAroundUser,
            0, 0);
        downloadResult.Set(handle);
    }

    void OnScoresDownloaded(LeaderboardScoresDownloaded_t result, bool ioFailure)
    {
        if (ioFailure)
        {
            Debug.LogWarning("[Leaderboard] Download failed.");
            if (lastFetchKind == FetchKind.MyRank)
                OnMyRankFetched?.Invoke(null);
            else
                OnEntriesFetched?.Invoke(new List<LeaderboardEntry>());
            return;
        }

        var entries = new List<LeaderboardEntry>();
        for (int i = 0; i < result.m_cEntryCount; i++)
        {
            LeaderboardEntry_t e;
            SteamUserStats.GetDownloadedLeaderboardEntry(
                result.m_hSteamLeaderboardEntries, i, out e, null, 0);

            entries.Add(new LeaderboardEntry
            {
                rank = e.m_nGlobalRank,
                steamId = e.m_steamIDUser.m_SteamID,
                steamName = SteamFriends.GetFriendPersonaName(e.m_steamIDUser),
                score = e.m_nScore,
                distanceKM = (double)e.m_nScore * SCORE_DIVISOR
            });
        }

        Debug.Log($"[Leaderboard] Downloaded {entries.Count} entries (kind={lastFetchKind})");

        if (lastFetchKind == FetchKind.MyRank)
            OnMyRankFetched?.Invoke(entries.Count > 0 ? entries[0] : null);
        else
            OnEntriesFetched?.Invoke(entries);
    }
}

/// <summary>
/// Leaderboard 한 줄. UI에서 표시용.
/// </summary>
public class LeaderboardEntry
{
    public int rank;
    public ulong steamId;
    public string steamName;
    public int score;       // 압축된 점수
    public double distanceKM; // 실제 km
}
