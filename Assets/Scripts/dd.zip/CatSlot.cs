using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/// <summary>
/// 도감 그리드의 한 칸.
/// 현재 사용 중인 고양이는: 슬롯 배경이 검게 + 별이 흐름 + 고양이 살짝 bobbing.
/// 마우스 호버 시 CatTooltip이 슬롯 위에 떠서 이름/설명 표시.
/// </summary>
public class CatSlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("References")]
    public Image slotBackground;   // 슬롯 회색 배경 (현재 슬롯일 때 색 전환)
    public Image catImage;
    public Button button;

    [Header("Current Cat Indicator")]
    public Color currentBgColor = new Color(0.05f, 0.05f, 0.08f, 1f); // 우주 검은빛
    public float bobAmplitude = 2f;
    public float bobSpeed = 2f;

    private int catId = -1;
    private bool isOwned;
    private bool isCurrent;
    private bool isLocked; // 데모에서 잠긴 고양이

    private Color normalBgColor = Color.gray;
    private Vector2 catBasePos;
    private SlotStarfield starfield;

    void Awake()
    {
        if (slotBackground != null)
            normalBgColor = slotBackground.color;
        if (catImage != null)
            catBasePos = catImage.rectTransform.anchoredPosition;

        CreateStarfield();
    }

    void CreateStarfield()
    {
        GameObject sf = new GameObject("Starfield");
        RectTransform sfRt = sf.AddComponent<RectTransform>();
        sfRt.SetParent(transform, false);

        sfRt.anchorMin = Vector2.zero;
        sfRt.anchorMax = Vector2.one;
        sfRt.offsetMin = Vector2.zero;
        sfRt.offsetMax = Vector2.zero;

        starfield = sf.AddComponent<SlotStarfield>();

        // catImage 뒤에 그려지도록
        if (catImage != null)
            sf.transform.SetSiblingIndex(catImage.transform.GetSiblingIndex());

        sf.SetActive(false);
    }

    void Start()
    {
        if (button != null)
            button.onClick.AddListener(OnClick);
    }

    void Update()
    {
        if (!isCurrent || catImage == null) return;

        float offset = Mathf.Sin(Time.time * bobSpeed) * bobAmplitude;
        Vector2 p = catBasePos;
        p.y += offset;
        catImage.rectTransform.anchoredPosition = p;
    }

    public void Setup(int id, Sprite sprite, bool owned, bool locked = false)
    {
        catId = id;
        isOwned = owned;
        isLocked = locked;

        if (catImage != null)
        {
            catImage.sprite = sprite;
            if (locked)
                catImage.color = new Color(0.4f, 0.4f, 0.4f, 1f); // 회색
            else
                catImage.color = owned ? Color.white : new Color(1, 1, 1, 0.9f);
            catImage.enabled = (sprite != null);
        }

        if (button != null)
            button.interactable = owned && !locked;
    }

    public void Clear()
    {
        catId = -1;
        SetCurrent(false);
        if (catImage != null) catImage.enabled = false;
        if (button != null) button.interactable = false;
    }

    public void SetCurrent(bool current)
    {
        if (isCurrent == current) return;
        isCurrent = current;

        if (slotBackground != null)
            slotBackground.color = current ? currentBgColor : normalBgColor;

        if (starfield != null)
            starfield.gameObject.SetActive(current);

        if (!current && catImage != null)
            catImage.rectTransform.anchoredPosition = catBasePos;
    }

    void OnClick()
    {
        if (!isOwned || catId < 0) return;
        if (CatManager.Instance == null) return;

        CatManager.Instance.SetCurrentCat(catId);

        CatCollectionUI parent = GetComponentInParent<CatCollectionUI>();
        if (parent != null && parent.closeButton != null)
            parent.closeButton.onClick.Invoke();
    }

    // ============ 호버 툴팁 ============

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (catId < 0) return;

        // 툴팁이 아직 없으면 같은 캔버스에 생성
        if (CatTooltip.Instance == null)
        {
            Canvas canvas = GetComponentInParent<Canvas>();
            if (canvas != null && canvas.rootCanvas != null)
                CatTooltip.GetOrCreate(canvas.rootCanvas);
        }

        if (CatTooltip.Instance != null)
            CatTooltip.Instance.ShowFor(catId, transform as RectTransform, isOwned, isLocked);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (CatTooltip.Instance != null)
            CatTooltip.Instance.Hide();
    }

    void OnDisable()
    {
        // 슬롯이 비활성화될 때 (페이지 전환 등) 툴팁 같이 숨김
        if (CatTooltip.Instance != null)
            CatTooltip.Instance.Hide();
    }
}
